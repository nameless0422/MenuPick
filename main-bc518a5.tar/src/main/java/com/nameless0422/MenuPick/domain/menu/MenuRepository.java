package com.nameless0422.MenuPick.domain.menu;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface MenuRepository extends JpaRepository<Menu, Long>, JpaSpecificationExecutor<Menu> {

    /** 메뉴/카테고리/태그를 곱집합 없이 선형 행으로 읽는 대안 진단 projection. */
    @Query(value = """
            SELECT m.id AS menuId, 'MENU' AS kind, NULL AS textValue, NULL AS longValue,
                   FALSE AS categoryMatched
              FROM menus m
             WHERE m.user_id = :userId AND m.is_excluded = FALSE AND m.deleted_at IS NULL
            UNION ALL
            SELECT mc.menu_id, 'CATEGORY', mc.category, NULL,
                   CASE WHEN :filterCategories = FALSE THEN FALSE
                        ELSE mc.category IN (:categories) END
              FROM menu_categories mc JOIN menus m ON m.id = mc.menu_id
             WHERE m.user_id = :userId AND m.is_excluded = FALSE AND m.deleted_at IS NULL
            UNION ALL
            SELECT mt.menu_id, 'TAG', NULL, mt.tag_id, FALSE
              FROM menu_tags mt JOIN menus m ON m.id = mt.menu_id
             WHERE m.user_id = :userId AND m.is_excluded = FALSE AND m.deleted_at IS NULL
            """, nativeQuery = true)
    List<PickAlternativeFact> findPickAlternativeFacts(
            @Param("userId") Long userId,
            @Param("filterCategories") boolean filterCategories,
            @Param("categories") Set<String> categories);

    @Query(value = """
            SELECT mr.menu_id AS menuId, r.latitude AS latitude, r.longitude AS longitude
              FROM menu_restaurants mr
              JOIN menus m ON m.id = mr.menu_id
              JOIN restaurants r ON r.id = mr.restaurant_id
             WHERE m.user_id = :userId AND m.is_excluded = FALSE AND m.deleted_at IS NULL
               AND r.deleted_at IS NULL
            """, nativeQuery = true)
    List<PickAlternativeRestaurant> findPickAlternativeRestaurants(@Param("userId") Long userId);

    interface PickAlternativeFact {
        Long getMenuId();
        String getKind();
        String getTextValue();
        Long getLongValue();
        Long getCategoryMatched();
    }

    interface PickAlternativeRestaurant {
        Long getMenuId();
        java.math.BigDecimal getLatitude();
        java.math.BigDecimal getLongitude();
    }

    List<Menu> findAllByUserIdAndDeletedAtIsNull(Long userId);

    /**
     * 기본 메뉴를 두 번 넣지 않기 위한 확인({@code DefaultMenuProvisioner}).
     *
     * <p>다른 조회와 달리 {@code deletedAt}을 거르지 않는다 — 여기서 묻는 것은 "지금 보이는
     * 메뉴가 있는가"가 아니라 "이 계정이 메뉴를 가져 본 적이 있는가"이고, 기본 메뉴를 전부 지운
     * 계정에 다시 채워 넣지 않으려면 지워진 것도 세야 한다.
     */
    boolean existsByUserId(Long userId);

    /**
     * 조회 자체를 소유자 범위로 한정한다 — 타인의 메뉴는 "권한 없음(403)"이 아니라
     * "없음(404)"으로 처리해 리소스 존재 여부가 새어 나가지 않게 한다.
     */
    Optional<Menu> findByIdAndUserIdAndDeletedAtIsNull(Long id, Long userId);

    /**
     * 필터 없는 픽의 후보. 조건이 붙은 픽은 {@code PickCandidates}가 만든 Specification으로
     * 조인까지 SQL에 내려 조회한다 — 여기서 전량을 올린 뒤 자바로 거르지 않는다.
     */
    List<Menu> findAllByUserIdAndIsExcludedFalseAndDeletedAtIsNull(Long userId);

    /**
     * 필터를 하나도 걸지 않아도 뽑을 것이 있는가. 후보가 비었을 때 "필터가 좁아서"인지
     * "애초에 뽑을 메뉴가 없어서"인지를 가른다.
     *
     * <p>{@link #existsByUserId}와 묻는 것이 다르다. 그쪽은 "가져 본 적이 있는가"라
     * 지운 것까지 세지만, 여기는 지금 뽑힐 수 있는 것만 센다 — 전부 추천 제외해 둔 계정도
     * 여기서는 "없음"이다(할 일이 "제외를 풀어라"로 같기 때문에 따로 가르지 않는다).
     */
    boolean existsByUserIdAndIsExcludedFalseAndDeletedAtIsNull(Long userId);

    List<Menu> findAllByUserIdAndDeletedAtIsNullOrderByIdDesc(Long userId, Pageable pageable);

    List<Menu> findAllByUserIdAndDeletedAtIsNullAndIdLessThanOrderByIdDesc(
            Long userId, Long cursor, Pageable pageable);

    List<Menu> findAllByUserIdAndIsExcludedTrueAndDeletedAtIsNullOrderByIdDesc(Long userId);

    List<Menu> findAllByIdInAndUserIdAndDeletedAtIsNull(List<Long> ids, Long userId);

    // menu_tags, menu_categories는 엔티티가 아니라서(조인/컬렉션 테이블) 네이티브 쿼리로 삭제한다.
    @Modifying
    @Query(value = "DELETE FROM menu_tags WHERE menu_id IN (SELECT id FROM menus WHERE user_id = :userId)",
            nativeQuery = true)
    void deleteMenuTagsByUserId(@Param("userId") Long userId);

    @Modifying
    @Query(value = "DELETE FROM menu_categories WHERE menu_id IN (SELECT id FROM menus WHERE user_id = :userId)",
            nativeQuery = true)
    void deleteMenuCategoriesByUserId(@Param("userId") Long userId);

    @Modifying
    @Query("delete from Menu m where m.user.id = :userId")
    void deleteAllByUserId(@Param("userId") Long userId);
}
