package com.nameless0422.MenuPick.domain.tag;

import com.nameless0422.MenuPick.common.exception.BusinessException;
import com.nameless0422.MenuPick.common.exception.ErrorCode;
import com.nameless0422.MenuPick.domain.pick.PickPresetRepository;
import com.nameless0422.MenuPick.domain.tag.dto.TagRequest;
import com.nameless0422.MenuPick.domain.tag.dto.TagResponse;
import com.nameless0422.MenuPick.domain.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class TagService {

    private final TagRepository tagRepository;
    private final UserRepository userRepository;
    /** 태그 삭제가 빠른 픽에 검토 필요를 켜야 한다 — 근거는 deleteTag 주석. */
    private final PickPresetRepository pickPresetRepository;

    /**
     * 자동완성 결과 상한. 입력창 아래 목록이라 이보다 많이 보여줄 자리가 없고, 상한이 없으면
     * 태그가 많은 사용자의 키 입력 한 번이 수백 행을 직렬화해 내려보낸다.
     */
    private static final int MAX_SUGGESTIONS = 20;

    /**
     * 태그 관리 화면이 한 번에 받는 최대 개수.
     *
     * <p>자동완성보다 크다 — 여기서는 "다 보여주는" 것이 목적이라 20개에서 잘리면 화면이
     * 제 일을 못 한다. 그렇다고 무제한으로 두면 태그가 많은 계정에서 설정 화면 한 번이
     * 전 행을 직렬화하므로, 사람이 실제로 만들 수 있는 규모를 넉넉히 덮는 선에서 자른다.
     */
    private static final int MAX_MANAGED_TAGS = 200;

    /**
     * 내 태그 전체. 태그 관리 화면(설정)에서 쓴다.
     *
     * <p>{@link #searchTags}를 빈 키워드로 부르는 것으로 대신하지 않는다. 그쪽은 자동완성이라
     * 키워드가 비면 <b>의도적으로</b> 빈 목록을 준다 — 아무것도 입력하지 않은 입력창 아래에
     * 태그 20개를 펼치지 않기 위해서다. 그 규칙을 관리 화면 때문에 바꾸면 자동완성이 달라진다.
     */
    public List<TagResponse.TagInfo> listTags(Long userId) {
        return tagRepository.findAllByUserIdOrderByName(userId, PageRequest.of(0, MAX_MANAGED_TAGS))
                .stream()
                .map(t -> new TagResponse.TagInfo(t.getId(), t.getName(), t.getCreatedAt()))
                .toList();
    }

    public List<TagResponse.TagInfo> searchTags(Long userId, String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return List.of();
        }
        String pattern = escapeLike(keyword.trim()) + "%";
        return tagRepository
                .searchByNamePattern(userId, pattern, PageRequest.of(0, MAX_SUGGESTIONS)).stream()
                .map(t -> new TagResponse.TagInfo(t.getId(), t.getName(), t.getCreatedAt()))
                .toList();
    }

    /**
     * LIKE 와일드카드를 문자 그대로 취급하게 만든다.
     *
     * <p>이스케이프하지 않으면 {@code ?keyword=%} 하나로 자기 태그 전량이 내려온다.
     * 타인 데이터가 새지는 않지만 자동완성이 목록 덤프가 되고, {@code _}는 "아무 한 글자"라
     * 사용자가 기대한 것과 다른 결과가 나온다.
     *
     * <p>이스케이프 문자 자신을 먼저 치환해야 한다. 나중에 하면 방금 우리가 붙인 {@code !}까지
     * 다시 이스케이프해 패턴이 어긋난다.
     */
    private static String escapeLike(String value) {
        return value.replace("!", "!!")
                .replace("%", "!%")
                .replace("_", "!_");
    }

    @Transactional
    public TagResponse.TagInfo createTag(Long userId, TagRequest.Create request) {
        // 일반 경로에서 명확한 에러를 주기 위한 사전 검사. 동시 요청 레이스는 아래 catch가 받는다.
        tagRepository.findByUserIdAndName(userId, request.name())
                .ifPresent(t -> { throw new BusinessException(ErrorCode.TAG_DUPLICATE); });

        Tag tag;
        try {
            // IDENTITY 전략이라 save() 시점에 INSERT가 즉시 실행되므로 여기서 제약 위반을 잡을 수 있다.
            tag = tagRepository.save(Tag.builder()
                    .user(userRepository.getReferenceById(userId))
                    .name(request.name())
                    .build());
        } catch (DataIntegrityViolationException e) {
            // uq_tags_user_name(user_id, name) 위반 — check-then-act 사이에 끼어든 동시 생성
            throw new BusinessException(ErrorCode.TAG_DUPLICATE);
        }

        return new TagResponse.TagInfo(tag.getId(), tag.getName(), tag.getCreatedAt());
    }

    @Transactional
    public void deleteTag(Long userId, Long tagId) {
        Tag tag = tagRepository.findById(tagId)
                .orElseThrow(() -> new BusinessException(ErrorCode.TAG_NOT_FOUND));

        // 타인의 태그는 "권한 없음(403)"이 아니라 "없음(404)"으로 응답한다 — 리소스 존재 노출 차단.
        if (!tag.getUser().getId().equals(userId)) {
            throw new BusinessException(ErrorCode.TAG_NOT_FOUND);
        }

        // 이 태그를 쓰던 빠른 픽에 검토 필요를 켠다. **태그를 지우기 전에** 해야 한다 —
        // 지운 뒤에는 어느 프리셋이 이 태그를 참조했는지 알 방법이 없다(FK cascade가 이미
        // 자식 행을 지웠다). 표시하지 않으면 그 프리셋은 조건 하나가 조용히 빠진 채 계속
        // 돌고, "견과류 제외"를 걸어 둔 사용자가 견과류를 추천받는다.
        //
        // 버전도 함께 올린다. 미리보기 화면을 띄워 둔 채 다른 탭에서 태그를 지웠다면
        // 그 화면이 들고 있는 버전으로는 실행되지 않아야 한다(PickPresetRepository 주석 참고).
        pickPresetRepository.markNeedsReviewByTagId(tagId);

        // 연결된 메뉴를 M건 로드해 컬렉션에서 하나씩 빼면 메뉴 수만큼 쿼리가 늘어난다.
        // 조인 테이블을 tag_id로 한 번에 지운다.
        tagRepository.deleteMenuTagsByTagId(tagId);

        tagRepository.delete(tag);
    }
}
