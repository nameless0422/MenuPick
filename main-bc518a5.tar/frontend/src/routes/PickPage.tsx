import { forwardRef, useDeferredValue, useEffect, useId, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { requestPick, type PickRequest, type PickResult } from "../api/pick";
import {
  isPickAlternativesUnavailable,
  pickAlternativesEnabled,
  requestPickAlternatives,
  type PickAlternative,
} from "../api/pickAlternatives";
import { recordPickFeedback, type RecommendationFeedback } from "../api/history";
import { fetchAllTags, searchTags } from "../api/tags";
import { fetchDefaultExcludedTagIds } from "../api/pickPreferences";
import type { TagSummary } from "../api/menus";
import { apiErrorCode, apiErrorMessage } from "../api/http";
import PickPresets from "./PickPresets";
import PickTrends from "./PickTrends";
import PickAlternatives from "./PickAlternatives";
import SavePickPresetForm from "./SavePickPresetForm";
import type { PickPresetExecutionResult } from "../api/pickPresets";
import { chipAction, chipClass, chipToggle } from "../a11y/chipToggle";
import { useRadioGroup } from "../a11y/radioGroup";
import { CATEGORY_PRESETS } from "../constants";
import KakaoMap from "../maps/KakaoMap";
import { addTrendCategory } from "./trendValidation";
import "./PickPage.css";

const SLOT_EMOJIS = ["🍚", "🍜", "🍕", "🍣", "🍔", "🥘", "🍝", "🌮", "🍗", "🥟", "🍛", "🥗"];
const SPIN_MS = 1200; // 슬롯머신 연출 최소 시간 — 응답이 더 빨라도 이만큼은 돌린다
const DISTANCE_OPTIONS = [300, 500, 1000, 2000, 5000];

type GeoState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "ready"; latitude: number; longitude: number }
  | { status: "error" };

/** Set 의미인 필드는 선택 순서가 달라도 같은 조건으로 비교한다. */
function pickRequestFingerprint(request: PickRequest) {
  return JSON.stringify({
    ...(request.categories && {
      categories: [...new Set(request.categories.map((value) => value.trim()))].sort(),
    }),
    ...(request.tagIds && { tagIds: [...new Set(request.tagIds)].sort((a, b) => a - b) }),
    ...(request.excludeTagIds && {
      excludeTagIds: [...new Set(request.excludeTagIds)].sort((a, b) => a - b),
    }),
    ...(request.latitude !== undefined && { latitude: request.latitude }),
    ...(request.longitude !== undefined && { longitude: request.longitude }),
    ...(request.maxDistance !== undefined && { maxDistance: request.maxDistance }),
  });
}

/**
 * 후보가 비었을 때 무엇을 하라고 할 것인가.
 *
 * 셋을 하나로 뭉쳐 두면 화면이 틀린 조언을 한다. 기본 메뉴 22개를 받고 시작한 신규 사용자가
 * 거리 필터를 켜면 후보가 비는데, 그에게 "메뉴를 추가해 보세요"는 도움이 되지 않는다 —
 * 메뉴는 넘치고 없는 것은 식당 연결이다. 서버가 이유를 코드로 갈라 준다.
 */
const EMPTY_REASONS: Record<
  string,
  { message: string; cta: string; to: string } | undefined
> = {
  NO_PICKABLE_MENUS: {
    message:
      "뽑을 메뉴가 없어요. 메뉴를 추가하거나, 추천에서 빼 둔 메뉴가 있다면 다시 포함시켜 주세요.",
    cta: "내 메뉴 관리하러 가기",
    to: "/menus",
  },
  NO_LINKED_RESTAURANTS: {
    // 반경을 넓히라고 하지 않는다 — 연결이 0건이면 아무리 넓혀도 후보는 비어 있다.
    message:
      "거리로 뽑으려면 메뉴에 식당이 연결되어 있어야 해요. 아직 연결된 식당이 없어서 반경을 넓혀도 결과가 나오지 않아요. 식당을 저장한 뒤 메뉴에 연결해 주세요.",
    cta: "식당 관리하러 가기",
    to: "/restaurants",
  },
  NO_PICK_CANDIDATES: {
    message:
      "조건에 맞는 메뉴가 없어요. 필터를 풀거나, 거리로 뽑는 중이라면 반경을 넓혀 보세요.",
    cta: "내 메뉴 관리하러 가기",
    to: "/menus",
  },
};

export default function PickPage() {
  // 필터 <section>을 랜드마크로 세우려면 이름이 필요하다 — 그 이름을 주는 제목의 id.
  const filtersHeadingId = useId();

  // ---- 필터 상태 ----
  const categoryFieldset = useRef<HTMLFieldSetElement>(null);
  const [categories, setCategories] = useState<string[]>([]);
  const [includeTags, setIncludeTags] = useState<TagSummary[]>([]);
  const [excludeTags, setExcludeTags] = useState<TagSummary[]>([]);
  const defaultsQuery = useQuery({
    queryKey: ["pick-preferences"],
    queryFn: async () => {
      const [ids, tags] = await Promise.all([fetchDefaultExcludedTagIds(), fetchAllTags()]);
      return tags.filter((tag) => ids.includes(tag.id));
    },
  });
  const defaultsApplied = useRef(false);
  useEffect(() => {
    if (!defaultsApplied.current && defaultsQuery.data) {
      defaultsApplied.current = true;
      setExcludeTags(defaultsQuery.data.map(({ id, name }) => ({ id, name })));
    }
  }, [defaultsQuery.data]);
  // 빠른 픽 실행 결과. 수동 픽과 같은 카드로 보여주되 출처가 다르므로 따로 담는다 —
  // 하나로 합치면 "방금 무엇으로 뽑았는지"를 화면이 구분해 말할 수 없다.
  const [presetResult, setPresetResult] = useState<PickPresetExecutionResult | null>(null);
  const [presetBusy, setPresetBusy] = useState(false);
  const [presetSelectionResetKey, setPresetSelectionResetKey] = useState(0);
  const [geo, setGeo] = useState<GeoState>({ status: "idle" });
  const [maxDistance, setMaxDistance] = useState(500);
  // 거리 선택지는 <legend>거리</legend>가 이름을 준다 — radiogroup은 fieldset 밖의
  // 별도 요소라 legend가 자동으로 붙지 않는다.
  const distanceLabelId = useId();
  const distanceGroup = useRadioGroup(DISTANCE_OPTIONS, maxDistance, setMaxDistance);

  // ---- 슬롯머신 연출 상태 ----
  const [spinning, setSpinning] = useState(false);
  const [slot, setSlot] = useState("🎲");
  const spinStartRef = useRef(0);
  const spinTimerRef = useRef<number | undefined>(undefined);

  // 초당 12.5회 이모지 교체는 전정기관이 민감한 사용자에게 불필요한 부하다. 연출만 빼고
  // 최소 대기(SPIN_MS)와 "메뉴를 뽑는 중…" 통지는 그대로 두므로 흐름은 달라지지 않는다.
  // 이 앱의 유일한 모션이라 CSS 쪽에는 대응할 것이 없다.
  // 마운트할 때 한 번만 읽는다 — 렌더마다 matchMedia를 부를 이유가 없고, 세션 도중
  // 설정을 바꾸는 일은 드물다(바꾸면 새로고침으로 반영된다).
  const [reduceMotion] = useState(
    () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false,
  );

  useEffect(() => {
    if (!spinning || reduceMotion) return;
    const id = window.setInterval(() => {
      setSlot(SLOT_EMOJIS[Math.floor(Math.random() * SLOT_EMOJIS.length)]);
    }, 80);
    return () => window.clearInterval(id);
  }, [spinning, reduceMotion]);

  // 언마운트 시 결과 공개 타이머 정리
  useEffect(() => () => window.clearTimeout(spinTimerRef.current), []);

  const pickMutation = useMutation({
    mutationFn: (request: PickRequest) => requestPick(request),
    onSettled: () => {
      setAlternativesApplying(false);
      // 응답이 최소 연출 시간보다 빨리 오면 남은 시간만큼 더 돌리고 나서 공개
      const remaining = Math.max(0, SPIN_MS - (Date.now() - spinStartRef.current));
      window.clearTimeout(spinTimerRef.current);
      spinTimerRef.current = window.setTimeout(() => setSpinning(false), remaining);
    },
  });

  // 돌리는 중인지. disabled 대신 이 값으로 aria-busy/aria-disabled를 주고 핸들러에서
  // 조기 반환한다 — disabled는 초점을 받지 못해 누른 그 버튼에서 <body>로 떨어뜨린다.
  const busy = spinning || pickMutation.isPending;
  const interactionBusy = busy || presetBusy;
  const pickButton = useRef<HTMLButtonElement>(null);

  const [alternatives, setAlternatives] = useState<PickAlternative[]>([]);
  const [alternativesLoading, setAlternativesLoading] = useState(false);
  const [alternativesApplying, setAlternativesApplying] = useState(false);
  const alternativesAbort = useRef<AbortController | null>(null);
  const alternativesFingerprint = useRef<string | null>(null);
  const alternativesPanel = useRef<HTMLDivElement>(null);

  const buildRequest = (): PickRequest => ({
    ...(categories.length > 0 && { categories }),
    ...(includeTags.length > 0 && { tagIds: includeTags.map((t) => t.id) }),
    // 빈 배열도 보낸다. 그래야 기본 제외 태그를 이번 픽에서 전부 해제한 의사가 서버에 전달된다.
    excludeTagIds: excludeTags.map((t) => t.id),
    ...(geo.status === "ready" && {
      latitude: geo.latitude,
      longitude: geo.longitude,
      maxDistance,
    }),
  });

  const requestFingerprint = pickRequestFingerprint(buildRequest());
  useEffect(() => {
    alternativesAbort.current?.abort();
    alternativesAbort.current = null;
    alternativesFingerprint.current = null;
    setAlternatives([]);
    setAlternativesLoading(false);
  }, [requestFingerprint]);
  useEffect(() => () => alternativesAbort.current?.abort(), []);

  const loadAlternatives = (request: PickRequest) => {
    if (!pickAlternativesEnabled()) return;
    alternativesAbort.current?.abort();
    const controller = new AbortController();
    const fingerprint = pickRequestFingerprint(request);
    alternativesAbort.current = controller;
    alternativesFingerprint.current = fingerprint;
    setAlternatives([]);
    setAlternativesLoading(true);
    requestPickAlternatives(request, controller.signal)
      .then(({ alternatives: offered }) => {
        if (controller.signal.aborted || alternativesFingerprint.current !== fingerprint) return;
        setAlternatives(offered);
        if (offered.length > 0) window.setTimeout(() => alternativesPanel.current?.focus(), 0);
      })
      .catch((requestError) => {
        if (controller.signal.aborted || alternativesFingerprint.current !== fingerprint) return;
        // 기능 플래그가 꺼진 서버의 404와 진단 실패는 기존 픽 오류를 가리지 않는다.
        if (!isPickAlternativesUnavailable(requestError)) setAlternatives([]);
      })
      .finally(() => {
        if (!controller.signal.aborted && alternativesFingerprint.current === fingerprint) {
          setAlternativesLoading(false);
        }
      });
  };

  // 수동으로 돌리면 프리셋 결과는 더 이상 지금 화면의 답이 아니다.
  const spin = () => {
    // aria-disabled는 표시일 뿐 클릭을 막지 않는다. 이 조기 반환이 실제 방어선이다.
    if (interactionBusy) return;
    // "다시 돌리기"는 결과 카드 안에 있는데, 돌리기 시작하면 결과가 감춰지며 그 카드가
    // 통째로 사라진다 — 누른 버튼이 없어져 초점이 <body>로 떨어진다. 지금 돌아가는 픽
    // 버튼으로 옮기면 진행 상태가 그대로 읽히고, 끝난 자리에서 바로 다시 돌릴 수 있다.
    // 픽 버튼에서 눌렀다면 이미 그 버튼이므로 아무 일도 일어나지 않는다.
    pickButton.current?.focus();
    setPresetResult(null);
    setAlternativesApplying(false);
    spinStartRef.current = Date.now();
    setSpinning(true);
    pickMutation.mutate(buildRequest());
  };

  // 거리 필터 토글: 켤 때 현재 위치를 얻고, 실패하면 비활성 상태로 안내만 남긴다.
  //
  // getCurrentPosition은 취소할 방법이 없다(최대 10초까지 매달린다). 그래서 요청마다 세대 번호를
  // 매기고, 콜백이 돌아왔을 때 자기 세대가 아직 최신인지 확인한다. 이 가드가 없으면:
  //  - 껐는데 뒤늦게 성공 콜백이 도착해 체크박스가 스스로 다시 켜지고, 사용자가 끈 거리 필터가
  //    다음 픽에 조용히 적용된다.
  //  - 껐다 켜기를 반복하면 먼저 보낸 요청이 나중에 끝나면서 오래된 좌표가 최신 좌표를 덮어쓴다.
  //  - 껐는데 뒤늦게 실패 콜백이 도착해, 쓰지도 않는 필터의 권한 오류 안내가 뜬다.
  const geoGeneration = useRef(0);

  // 언마운트된 뒤 도착하는 콜백도 같은 방식으로 무효화한다.
  useEffect(() => () => { geoGeneration.current += 1; }, []);

  const toggleDistanceFilter = () => {
    // 끄는 경우에도 세대를 올려야 진행 중이던 요청의 결과가 되살아나지 않는다.
    const generation = ++geoGeneration.current;
    const isCurrent = () => geoGeneration.current === generation;

    if (geo.status === "ready" || geo.status === "loading") {
      setGeo({ status: "idle" });
      return;
    }
    if (!("geolocation" in navigator)) {
      setGeo({ status: "error" });
      return;
    }
    setGeo({ status: "loading" });
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        if (!isCurrent()) return;
        setGeo({
          status: "ready",
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        });
      },
      () => {
        if (!isCurrent()) return;
        setGeo({ status: "error" });
      },
      { timeout: 10_000 },
    );
  };

  const revealed = !busy;
  const result = revealed && pickMutation.isSuccess ? pickMutation.data : null;
  const error = revealed && pickMutation.isError ? pickMutation.error : null;
  // 후보가 비는 이유는 셋이고 할 일이 각각 다르다 — 서버가 코드로 갈라 준다(PickService.diagnoseEmpty).
  const emptyReason = error == null ? undefined : EMPTY_REASONS[apiErrorCode(error) ?? ""];

  const failedRequest = pickMutation.variables;
  useEffect(() => {
    if (!revealed || !error || apiErrorCode(error) !== "NO_PICK_CANDIDATES") return;
    // 픽이 진행되는 동안 필터를 편집할 수 있다. A 조건으로 보낸 픽이 실패한 뒤 화면이 이미
    // B 조건이면, B를 진단해 A의 실패에 붙이는 것은 서로 다른 요청을 섞는 일이다.
    if (!failedRequest || pickRequestFingerprint(failedRequest) !== requestFingerprint) {
      alternativesAbort.current?.abort();
      alternativesFingerprint.current = null;
      setAlternatives([]);
      setAlternativesLoading(false);
      return;
    }
    loadAlternatives(failedRequest);
    // loadAlternatives는 이 effect가 붙잡은 실패 요청에만 한 번 실행되어야 한다.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [revealed, error, failedRequest, requestFingerprint]);

  const applyAlternative = (alternative: PickAlternative) => {
    if (interactionBusy || alternativesApplying) return;
    alternativesAbort.current?.abort();
    setAlternatives([]);
    setAlternativesLoading(false);
    setAlternativesApplying(true);
    setPresetResult(null);
    setPresetSelectionResetKey((current) => current + 1);
    const nextRequest = buildRequest();
    if (alternative.changes.categories) {
      setCategories([]);
      delete nextRequest.categories;
    }
    if (alternative.changes.maxDistance != null) {
      setMaxDistance(alternative.changes.maxDistance);
      nextRequest.maxDistance = alternative.changes.maxDistance;
    }
    pickButton.current?.focus();
    spinStartRef.current = Date.now();
    setSpinning(true);
    pickMutation.mutate(nextRequest);
  };

  return (
    <div className="page">
      <header className="page-header">
        <h1>오늘 뭐 먹지</h1>
      </header>

      {/* 이름 없는 <section>은 랜드마크로 노출되지 않는다 — 스크린리더의 랜드마크 목록에
          잡히지 않아 실질적으로 <div>였고, 필터 뭉치를 건너뛰어 뽑기 버튼으로 가거나
          반대로 필터로 되돌아오려면 fieldset 네 개를 Tab으로 헤집는 수밖에 없었다.
          제목은 화면에 내지 않는다 — 눈으로 보는 사람에게는 각 fieldset의 legend
          (카테고리·포함 태그·제외 태그·거리)가 이미 구조를 보여주고 있어, 그 위에
          "픽 조건"을 한 줄 더 세우면 같은 말을 두 번 하는 셈이 된다. */}
      <PickPresets
        resetSelectionKey={presetSelectionResetKey}
        onBusyChange={setPresetBusy}
        tagNameOf={(id) =>
          defaultsQuery.data?.find((t) => t.id === id)?.name
            ?? includeTags.find((t) => t.id === id)?.name
            ?? excludeTags.find((t) => t.id === id)?.name
            ?? `#${id}`
        }
        onResult={(executed) => {
          alternativesAbort.current?.abort();
          setAlternatives([]);
          setPresetResult(executed);
          setSpinning(false);
        }}
      />

      <section className="pick-filters" aria-labelledby={filtersHeadingId}>
        <h2 className="sr-only" id={filtersHeadingId}>픽 조건</h2>
        <CategoryFilter ref={categoryFieldset} selected={categories} onChange={setCategories} />
        <TagFilter
          legend="포함 태그"
          placeholder="이 태그가 모두 있는 메뉴만 (예: 혼밥)"
          selected={includeTags}
          disabledTags={excludeTags}
          onChange={setIncludeTags}
        />
        <TagFilter
          legend="제외 태그"
          placeholder="이 태그가 있는 메뉴는 제외 (예: 느끼함)"
          selected={excludeTags}
          disabledTags={includeTags}
          onChange={setExcludeTags}
        />

        <fieldset>
          <legend id={distanceLabelId}>거리</legend>
          <label className="pick-distance-toggle">
            <input
              type="checkbox"
              checked={geo.status === "ready" || geo.status === "loading"}
              onChange={toggleDistanceFilter}
            />
            내 위치 기준으로 가까운 곳만
            {geo.status === "loading" && <small>위치 확인 중…</small>}
          </label>
          {/* 최대 10초 뒤에 비동기로 나타나고, 그때 체크박스가 스스로 꺼진다. 알리지 않으면
              스크린리더 사용자에게는 이유 없이 되돌아간 것으로만 보인다. */}
          {geo.status === "error" && (
            <p className="pick-geo-error" role="alert">
              위치를 가져오지 못해 거리 필터를 쓸 수 없어요. 브라우저의 위치 권한을 확인해 주세요.
            </p>
          )}
          {geo.status === "ready" && (
            /* 여기는 토글 버튼 무리가 아니라 단일 선택 그룹이다 — 항상 정확히 하나가
               선택돼 있고 해제할 수단이 없다. aria-pressed로 두면 스크린리더가
               "500m 이내, 눌림"만 읽고 방금 300m가 풀렸다는 사실은 전달되지 않아,
               선택이 옮겨 간 것이 아니라 하나가 더 켜진 것처럼 들린다.
               역할과 함께 화살표 키 이동·roving tabindex도 온다 — 근거는 useRadioGroup. */
            <div className="chip-row" {...distanceGroup.groupProps} aria-labelledby={distanceLabelId}>
              {DISTANCE_OPTIONS.map((meters, index) => (
                <button
                  key={meters}
                  type="button"
                  className={chipClass(maxDistance === meters)}
                  {...distanceGroup.radioProps(meters, index)}
                >
                  {formatDistance(meters)} 이내
                </button>
              ))}
            </div>
          )}
        </fieldset>
      </section>

      <div className="pick-stage">
        {/* 돌리는 동안 유일한 자식이 aria-hidden이라 접근 가능한 이름이 빈 문자열이 됐다.
            이름은 "지금 무엇을 하는 버튼인가"이므로 상태에 따라 바뀌면 안 된다 — 눈에만
            안 보이게 남겨 두면 돌아가는 중에도 같은 버튼으로 읽힌다. 진행 여부는 이름이
            아니라 aria-busy가 알린다. */}
        <button
          ref={pickButton}
          className="pick-button"
          onClick={spin}
          aria-busy={busy}
          aria-disabled={interactionBusy}
        >
          {busy ? (
            <>
              <span className="pick-slot" aria-hidden="true">{reduceMotion ? "🎲" : slot}</span>
              <span className="sr-only">오늘의 메뉴 뽑기</span>
            </>
          ) : (
            <>🎲 오늘의 메뉴 뽑기</>
          )}
        </button>

        <SavePickPresetForm
          categories={categories}
          includeTagIds={includeTags.map((t) => t.id)}
          excludeTagIds={excludeTags.map((t) => t.id)}
          defaultExcludedTagIds={(defaultsQuery.data ?? []).map((t) => t.id)}
          maxDistance={geo.status === "ready" ? maxDistance : null}
        />

        {pickMutation.isIdle && (
          <p className="card-muted-hint">
            아직 메뉴가 없다면 <Link to="/menus">내 메뉴</Link>에서 자주 먹는 메뉴부터 등록해 보세요.
          </p>
        )}
      </div>

      {/* 픽 결과는 화면 일부만 조용히 바뀐다 — 알림이 없으면 스크린리더 사용자는
          버튼을 눌러도 무엇이 뽑혔는지 알 수 없다. 이 앱의 핵심 동작이라 반드시 필요하다. */}
      <div role="status" aria-live="polite">
        {/* 뽑는 동안 이 리전이 비어 있으면 Enter를 친 뒤 최소 1.2초가 완전한 무음이 된다.
            돌아가는 이모지는 aria-hidden이라 들리는 것이 하나도 없다. */}
        {(spinning || pickMutation.isPending) && <p className="sr-only">메뉴를 뽑는 중…</p>}
        {presetResult && (
          <>
            <PickResultCard result={presetResult.pick} onRetry={spin} />
            {/* 미리보기 뒤 기본 제외가 바뀌었을 수 있다 — 서버가 실제로 쓴 조건이 권위 있다. */}
            <p className="settings-desc">
              빠른 픽으로 뽑았어요. 실제 적용된 제외 태그{" "}
              {presetResult.appliedFilters.effectiveExcludeTagIds.length}개
              {presetResult.appliedFilters.maxDistance != null &&
                `, ${presetResult.appliedFilters.maxDistance}m 이내`}
            </p>
          </>
        )}
        {!presetResult && result && <PickResultCard result={result} onRetry={spin} />}

        {emptyReason && (
          <div className="card pick-empty">
            <p>{emptyReason.message}</p>
            <Link to={emptyReason.to}>{emptyReason.cta} →</Link>
          </div>
        )}
      </div>
      {apiErrorCode(error) === "NO_PICK_CANDIDATES" && (
        <PickAlternatives
          ref={alternativesPanel}
          alternatives={alternatives}
          loading={alternativesLoading}
          applying={alternativesApplying}
          onApply={applyAlternative}
        />
      )}
      {error && !emptyReason && <p className="error" role="alert">{apiErrorMessage(error)}</p>}

      {/* 맨 아래에 둔다. 곁다리 정보라 뽑기 버튼과 결과를 밀어내면 안 되고, 표본이 모이기
          전까지는 "아직 없어요" 한 줄만 있는 패널이라 더욱 그렇다. 누르면 위 픽 조건에
          카테고리가 들어가므로 다음 행동은 화면 위쪽에서 이어진다. */}
      <PickTrends
        busy={interactionBusy}
        onPickCategory={(category) => {
          if (interactionBusy) return;
          setCategories((current) =>
            // 순위 칩은 더하기만 한다 — 같은 칩을 두 번 눌러 방금 켠 조건이 꺼지면,
            // 토글이라고 말한 적 없는 버튼이 토글처럼 군 셈이 된다.
            addTrendCategory(current, category),
          );
          setPresetResult(null);
          setPresetSelectionResetKey((current) => current + 1);
          categoryFieldset.current?.focus();
        }}
      />
    </div>
  );
}

// retrying prop이 있었지만 늘 false였다 — 돌리기 시작하면 result가 null이 되어 이 카드가
// 먼저 사라지기 때문이다. 초점은 대신 spin()이 픽 버튼으로 옮긴다.
function PickResultCard({
  result,
  onRetry,
}: {
  result: PickResult;
  onRetry: () => void;
}) {
  const { menu, restaurants } = result;
  // 백엔드와 프론트 이미지가 교체되는 짧은 전환 구간에 구버전 응답을 받아도 카드 전체가
  // 깨지지 않게 한다. reasons는 부가 설명이지 픽 결과의 필수 데이터가 아니다.
  const reasons = result.reasons ?? [];
  const [feedback, setFeedback] = useState<RecommendationFeedback | null>(null);
  const feedbackMutation = useMutation({
    mutationFn: (value: RecommendationFeedback) => recordPickFeedback(result.historyId, value),
    onSuccess: (_, value) => setFeedback(value),
  });
  // 이 카드는 픽이 도착한 순간에 마운트되므로, 마운트 시각이 곧 뽑은 시각이다.
  // 렌더마다 new Date()를 부르면 리렌더할 때마다 표에 찍힌 시각이 바뀐다 —
  // 초기화 함수로 한 번만 붙잡아 둔다.
  const [pickedAt] = useState(() => new Date());
  return (
    <div className="card pick-result">
      {/* 발권부. 높이가 PickPage.css의 --perf-y와 맞물려 있어 안쪽 글자는 줄바꿈되면 안 된다. */}
      <div className="pick-ticket-stub">
        <span className="pick-result-label">오늘의 픽 🎉</span>
        {/* 히스토리는 시각순으로 쌓이고 같은 메뉴가 여러 번 나올 수 있다 — 이 표를
            나중에 히스토리에서 짚으려면 이름이 아니라 시각이 필요하다. */}
        <time className="pick-ticket-time" dateTime={pickedAt.toISOString()}>
          {formatTime(pickedAt)}
        </time>
      </div>
      <div className="pick-ticket-body">
      <strong className="pick-result-name">{menu.name}</strong>
      {menu.memo && <p className="pick-result-memo">{menu.memo}</p>}

      {reasons.length > 0 && (
        <div className="pick-reasons" aria-label="추천 이유">
          <strong>이 메뉴를 고른 이유</strong>
          <ul>
            {reasons.map((reason) => <li key={reason}>{reason}</li>)}
          </ul>
        </div>
      )}

      {(menu.categories.length > 0 || menu.tags.length > 0) && (
        <div className="chip-row">
          {menu.categories.map((category) => (
            <span key={category} className="chip">{category}</span>
          ))}
          {menu.tags.map((tag) => (
            <span key={tag.id} className="chip chip-tag">#{tag.name}</span>
          ))}
        </div>
      )}

      {/* 추천 식당은 목록에 그대로 두고 지도를 덧붙인다. 지도가 안 떠도(키 미설정·로드 실패)
          어디로 가야 할지는 목록만으로 알 수 있어야 한다. */}
      <KakaoMap points={restaurants} ariaLabel={`${menu.name} 추천 식당 위치`} />

      {/* 지도를 못 보는 사람에게는 이 목록이 유일한 경로다. 몇 곳인지부터 알려야 한다.
          Safari + VoiceOver는 list-style: none이 걸린 <ul>의 목록 시맨틱을 지우므로
          role도 명시한다. */}
      {restaurants.length > 0 && (
        <>
        <p className="sr-only">{`추천 식당 ${restaurants.length}곳`}</p>
        <ul className="pick-restaurants" role="list">
          {restaurants.map((restaurant) => (
            <li key={restaurant.id}>
              <strong>{restaurant.name}</strong>
              {restaurant.address && <span className="pick-restaurant-address">{restaurant.address}</span>}
              {restaurant.distance != null && (
                <span className="chip">{formatDistance(restaurant.distance)}</span>
              )}
            </li>
          ))}
        </ul>
        </>
      )}

      <div className="card-actions">
        <button onClick={() => feedbackMutation.mutate("ACCEPTED")}
          disabled={feedbackMutation.isPending} aria-pressed={feedback === "ACCEPTED"}>
          👍 이걸로 먹을래요
        </button>
        <button onClick={() => feedbackMutation.mutate("REJECTED")}
          disabled={feedbackMutation.isPending} aria-pressed={feedback === "REJECTED"}>
          👎 별로예요
        </button>
        <button onClick={onRetry}>🔁 다시 돌리기</button>
        <Link to="/history">히스토리 보기 →</Link>
      </div>
      {feedback && <p className="card-muted-hint" role="status">의견을 저장했어요.</p>}
      </div>
    </div>
  );
}

const CategoryFilter = forwardRef<HTMLFieldSetElement, {
  selected: string[];
  onChange: (categories: string[]) => void;
}>(function CategoryFilter({
  selected,
  onChange,
}, ref) {
  const [custom, setCustom] = useState("");
  // 직접 입력한 카테고리는 selected에만 존재해서, 칩을 눌러 해제하는 순간 목록에서 영구히
  // 사라졌다 — 다시 쓰려면 처음부터 타이핑해야 하고, 방금 누른 버튼이 없어지니 초점도
  // <body>로 떨어졌다. 입력한 값을 따로 기억해 두면 칩이 언마운트되지 않으므로 두 문제가
  // 회피가 아니라 소멸로 해결된다. 프리셋 칩은 원래 목록에 남아 있어 같은 문제가 없다.
  const [customs, setCustoms] = useState<string[]>([]);
  const customInput = useRef<HTMLInputElement>(null);

  const toggle = (category: string) =>
    onChange(
      selected.includes(category)
        ? selected.filter((c) => c !== category)
        : [...selected, category],
    );

  const addCustom = () => {
    const value = custom.trim();
    setCustom("");
    // "추가"를 누르면 입력이 비어 그 버튼이 곧바로 disabled가 된다 — 방금 누른 버튼이
    // 초점을 받을 수 없게 되면서 초점이 <body>로 떨어진다. 다음 행동(다른 카테고리 입력)이
    // 시작되는 입력으로 옮기면 그 자리에서 이어서 칠 수 있다.
    customInput.current?.focus();
    if (!value) return;
    setCustoms((prev) => (prev.includes(value) ? prev : [...prev, value]));
    if (!selected.includes(value)) onChange([...selected, value]);
  };

  return (
    <fieldset ref={ref} tabIndex={-1}>
      <legend>카테고리</legend>
      <div className="chip-row">
        {[...new Set([...CATEGORY_PRESETS, ...customs, ...selected])].map((category) => (
          <button
            key={category}
            type="button"
            {...chipToggle(selected.includes(category))}
            onClick={() => toggle(category)}
          >
            {category}
          </button>
        ))}
      </div>
      {/* aria-label: placeholder는 접근 가능한 이름 계산의 최후 폴백이라 읽히지 않는 구현이
          있고, 타이핑을 시작하면 화면에서도 사라진다. (MenusPage의 CategoryPicker와 같은 처리) */}
      <div className="inline-add">
        <input
          ref={customInput}
          value={custom}
          onChange={(e) => setCustom(e.target.value)}
          maxLength={20}
          aria-label="직접 입력한 카테고리"
          placeholder="직접 입력"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addCustom();
            }
          }}
        />
        <button type="button" onClick={addCustom} disabled={!custom.trim()}>추가</button>
      </div>
    </fieldset>
  );
});

// MenusPage의 TagPicker와 같은 UX — 단, 픽 화면에서는 태그를 새로 만들 필요가 없어 검색/선택만 제공.
// disabledTags: 반대편(포함↔제외) 목록에 이미 들어간 태그는 제안에서 숨겨 모순된 필터를 막는다.
function TagFilter({
  legend,
  placeholder,
  selected,
  disabledTags,
  onChange,
}: {
  legend: string;
  placeholder: string;
  selected: TagSummary[];
  disabledTags: TagSummary[];
  onChange: (tags: TagSummary[]) => void;
}) {
  const [keyword, setKeyword] = useState("");
  const deferredKeyword = useDeferredValue(keyword);
  const searchInput = useRef<HTMLInputElement>(null);

  const tagsQuery = useQuery({
    queryKey: ["tags", deferredKeyword],
    queryFn: () => searchTags(deferredKeyword),
  });

  const suggestions = (tagsQuery.data ?? []).filter(
    (tag) =>
      !selected.some((s) => s.id === tag.id) &&
      !disabledTags.some((d) => d.id === tag.id),
  );

  // 태그는 고르든 풀든 누른 버튼이 사라진다 — 제안 칩은 선택 행으로 옮겨가고, 선택 칩은
  // 제안 행으로 돌아간다. 돌아갈 자리가 없으므로 초점을 검색 입력으로 모은다: 이 컨트롤의
  // 허브이고 다음 행동(다른 태그 검색)이 시작되는 곳이다. 이게 없으면 태그를 하나 고를
  // 때마다 페이지 맨 위에서 Tab을 다시 눌러 내려와야 한다.
  const selectTags = (next: TagSummary[]) => {
    onChange(next);
    searchInput.current?.focus();
  };

  return (
    <fieldset>
      <legend>{legend}</legend>
      {selected.length > 0 && (
        <div className="chip-row">
          {selected.map((tag) => (
            <button
              key={tag.id}
              type="button"
              {...chipToggle(true, "chip-tag")}
              aria-label={`${tag.name} 태그 선택 해제`}
              title="클릭하면 해제"
              onClick={() => selectTags(selected.filter((s) => s.id !== tag.id))}
            >
              #{tag.name} ✕
            </button>
          ))}
        </div>
      )}
      <div className="inline-add">
        {/* 이 컴포넌트는 "포함 태그"와 "제외 태그"로 두 번 렌더된다. legend는 fieldset에만
            붙어 있어 이름 계산에 들어오지 않으므로, 둘을 구분하려면 입력마다 이름이 있어야
            한다 — 없으면 음성 제어로 어느 쪽을 지목했는지 알 수 없다. */}
        <input
          ref={searchInput}
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          maxLength={50}
          aria-label={`${legend} 검색`}
          placeholder={placeholder}
        />
      </div>
      {tagsQuery.isError && <p className="error" role="alert">{apiErrorMessage(tagsQuery.error)}</p>}
      {suggestions.length > 0 && (
        <div className="chip-row">
          {suggestions.map((tag) => (
            // 제안 칩은 토글이 아니다 — 누르면 위 "선택된 태그" 줄로 옮겨 가며 여기서
            // 사라진다. chipToggle이 붙이던 aria-pressed="false"는 "다시 눌러 끌 수 있는
            // 버튼"이라는 약속이라 지켜지지 않았고, 대신 이름으로 무엇이 일어나는지 말한다.
            <button
              key={tag.id}
              type="button"
              {...chipAction("chip-tag")}
              aria-label={`${tag.name} 태그 추가`}
              onClick={() => selectTags([...selected, { id: tag.id, name: tag.name }])}
            >
              #{tag.name}
            </button>
          ))}
        </div>
      )}
    </fieldset>
  );
}

/** 발권 시각 표기. 히스토리의 목록과 같은 24시간 표기라 눈으로 바로 맞춰 볼 수 있다. */
function formatTime(date: Date) {
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function formatDistance(meters: number) {
  if (meters >= 1000) {
    const km = meters / 1000;
    return `${Number.isInteger(km) ? km : km.toFixed(1)}km`;
  }
  return `${Math.round(meters)}m`;
}
